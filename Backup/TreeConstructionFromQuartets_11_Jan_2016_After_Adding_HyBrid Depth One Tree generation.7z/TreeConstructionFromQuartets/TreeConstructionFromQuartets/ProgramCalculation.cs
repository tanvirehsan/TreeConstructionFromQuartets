﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TreeConstructionFromQuartets.Model;

namespace TreeConstructionFromQuartets
{
    public class ProgramCalculation
    {
        public List<string> getUnionOfTaxaList(List<string> root, List<string> current)
        {
            var distinct = root.Union(current).ToList();
            return distinct;
        }

        public void StepByStep()
        {
            #region Step:1 Find Depth One Chain and Consistancy Calculation
            ConsistancyCalculation obj = new ConsistancyCalculation();
            obj.CalculateConsistancy();

            // Getting the GainTable After Initial Bipartition
            GainTable GB = obj.getFinalGainTableAfterGainCalculation();
            // Getting Partition with maximum Gained Taxa 
            PartitionSet SetP = GB.PartitionSet;

            // Getting Differred, Isolated And Violated Quatret Before Devide and Conquer
            List<Quartet> _DifferedQuatretListAfterGain = obj.getDifferedQuatretListAfterGain();
            List<Quartet> _IsolatedQuatretListAfterGain = obj.getIsolatedQuatretListAfterGain();
            List<Quartet> _ViolatedQuatretListAfterGain = obj.getViolatedQuatretListAfterGain();

            // Getting Depth One Chain After Devide And Conquer
            List<ConsistencyDataModel> _ListConsistencyDataModel = obj.getListConsistencyDataModel();

            // Getting Consistent and Inconsistent Quatret 
            List<Quartet> _DifferredConsistentAfterDevideAndConquer = obj.getDifferedQuatretConsistentAfterDevideAndConquer();
            List<Quartet> _IsolatedConsistentAfterDevideAndConquer = obj.getIsolatedQuatretConsistentAfterDevideAndConquer();

            List<Quartet> _IsolatedInConsistentAfterDevideAndConquer = obj.getIsolatedQuatretInConsistentAfterDevideAndConquer();
            List<Quartet> _DifferredInConsistentAfterDevideAndConquer = obj.getDifferedQuatretInConsistentAfterDevideAndConquer();

            #endregion

            #region Step:2 Calculate Super Split List using All Violated Quatret

            SplitCalculation objSplitCalculation = new SplitCalculation();
            SplitModel SuperSplit = new SplitModel();
            if (_ViolatedQuatretListAfterGain.Count != 0)
            {
                SuperSplit = objSplitCalculation.CalculateSuperSplit(_ViolatedQuatretListAfterGain);
                OutputProcessing.WriteSplitValues(SuperSplit, "Super Split");
            }

            #endregion

            #region Step:3 Calculate Secondary Split


            SplitModel SecondarySplit = new SplitModel();
            if (_ViolatedQuatretListAfterGain.Count != 0)
            {
                SecondarySplit = objSplitCalculation.CalculateSecondarySplit(SetP, SuperSplit);

            }
            else
            {
                var vLeft = from t in SetP.PartitionList[0].TaxaList
                            select t._Taxa_Value;

                var vRight = from t in SetP.PartitionList[1].TaxaList
                             select t._Taxa_Value;

                SecondarySplit._InputQuatret = SuperSplit._InputQuatret;

                if (vLeft != null)
                {
                    if (vLeft.Count() != 0)
                    {
                        SecondarySplit._LeftPartOfSplit = vLeft.ToList();
                    }
                }

                if (vRight != null)
                {
                    if (vRight.Count() != 0)
                    {
                        SecondarySplit._RightPartOfSplit = vRight.ToList();
                    }
                }

                SecondarySplit._LeftPartOfSplit.Sort();
                SecondarySplit._RightPartOfSplit.Sort();
                SecondarySplit._CountTaxa = SecondarySplit._LeftPartOfSplit.Count() + SecondarySplit._RightPartOfSplit.Count();

            }
            OutputProcessing.WriteSplitValues(SecondarySplit, "Secondary Split");

            #endregion

            #region Step:4 Calculate HyBrid Split

            SplitModel HybridSplit = new SplitModel();
            List<Quartet> ListInConsistantQuatretsTotal = new List<Quartet>();

            // Get all Insistent Quartet = Differred Inconsistent Quartet + Isolated Inconsistant Quartet
            var allInConsistentQuartet = _DifferredInConsistentAfterDevideAndConquer.Union(_IsolatedInConsistentAfterDevideAndConquer).ToList();

            ListInConsistantQuatretsTotal = allInConsistentQuartet;

            if (ListInConsistantQuatretsTotal.Count != 0)
            {
                HybridSplit = objSplitCalculation.CalculateHyBridSplit(SetP, SecondarySplit, ListInConsistantQuatretsTotal);
                OutputProcessing.WriteSplitValues(HybridSplit, "Hybrid Split");

                List<string> _LeftHyBridPart = getUnionOfTaxaList(SecondarySplit._LeftPartOfSplit, HybridSplit._LeftPartOfSplit);
                List<string> _RightHyBridPart = getUnionOfTaxaList(SecondarySplit._RightPartOfSplit, HybridSplit._RightPartOfSplit);

                HybridSplit._InputQuatret = SecondarySplit._InputQuatret;
                HybridSplit._LeftPartOfSplit = _LeftHyBridPart;
                HybridSplit._RightPartOfSplit = _RightHyBridPart;
                HybridSplit._LeftPartOfSplit.Sort();
                HybridSplit._RightPartOfSplit.Sort();
                HybridSplit._CountTaxa = _LeftHyBridPart.Count() + _RightHyBridPart.Count();


                OutputProcessing.WriteSplitValues(HybridSplit, "Duplicate Split");

            }

            else
            {
                // Now Union Secondary and HyBrid

                List<string> _LeftHyBridPart = getUnionOfTaxaList(SecondarySplit._LeftPartOfSplit, HybridSplit._LeftPartOfSplit);
                List<string> _RightHyBridPart = getUnionOfTaxaList(SecondarySplit._RightPartOfSplit, HybridSplit._RightPartOfSplit);

                HybridSplit._InputQuatret = SecondarySplit._InputQuatret;
                HybridSplit._LeftPartOfSplit = _LeftHyBridPart;
                HybridSplit._RightPartOfSplit = _RightHyBridPart;
                HybridSplit._LeftPartOfSplit.Sort();
                HybridSplit._RightPartOfSplit.Sort();
                HybridSplit._CountTaxa = _LeftHyBridPart.Count() + _RightHyBridPart.Count();


                OutputProcessing.WriteSplitValues(HybridSplit, "Duplicate Split");
            }

            #endregion

            #region Step:4 Calculate HyBrid DepthOne List

            List<List<string>> HyBridDepthOneList = new List<List<string>>();
            HyBridDepthOneList = objSplitCalculation.getHyBridDepthOneTaxaList(SetP, HybridSplit);

            List<string> LeftMost = HyBridDepthOneList[0];
            List<string> RightMost = HyBridDepthOneList[1];

            List<DepthOneTreeNode> DepthOneTreeNodeLeft = new List<DepthOneTreeNode>();
            List<DepthOneTreeNode> DepthOneTreeNodeRight = new List<DepthOneTreeNode>();
            DepthOneTreeNode __node;
            int pos = 0;

            foreach (string tx in LeftMost)
            {
                __node = new DepthOneTreeNode();
                __node._Position = pos;
                __node._Taxa_Value = tx;
                pos++;
                DepthOneTreeNodeLeft.Add(__node);

            }


            pos = 0;
            foreach (string tx in RightMost)
            {
                __node = new DepthOneTreeNode();
                __node._Position = pos;
                __node._Taxa_Value = tx;
                pos++;
                DepthOneTreeNodeRight.Add(__node);

            }

            _ListConsistencyDataModel.Insert(0, new ConsistencyDataModel()
            {
                _Isolated_Quatret = _ListConsistencyDataModel[0]._Isolated_Quatret,
                _Differed_Quatret = _ListConsistencyDataModel[0]._Differed_Quatret,
                _Violated_Quatret = _ListConsistencyDataModel[0]._Violated_Quatret,
                _DepthOneChain = new List<DepthOneTreeNode>(DepthOneTreeNodeLeft)
            });

            _ListConsistencyDataModel.Add(new ConsistencyDataModel()
            {
                _Isolated_Quatret = _ListConsistencyDataModel[0]._Isolated_Quatret,
                _Differed_Quatret = _ListConsistencyDataModel[0]._Differed_Quatret,
                _Violated_Quatret = _ListConsistencyDataModel[0]._Violated_Quatret,
                _DepthOneChain = new List<DepthOneTreeNode>(DepthOneTreeNodeRight)
            });

            OutputProcessing.PrintHyBridDepthOneTree(_ListConsistencyDataModel);
            OutputProcessing.GenerateInputForHyBridDepthOneTree(_ListConsistencyDataModel);
            
            #endregion
        }
    }
}
