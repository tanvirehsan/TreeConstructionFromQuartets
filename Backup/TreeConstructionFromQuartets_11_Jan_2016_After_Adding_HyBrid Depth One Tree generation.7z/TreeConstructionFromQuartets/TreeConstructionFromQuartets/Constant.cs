﻿namespace TreeConstructionFromQuartets
{
    using System;
    public class Constant
    {
        //public static string InputFilePath = @"E:\Mizans Research\Project\20Test.txt";
        public static string InputFilePath = @"E:\Mizans Research\Project\200Test.txt";
        //public static string InputFilePath = @"E:\Mizans Research\Project\SampleViolatedQuatret.txt";
        //public static string InputFilePath = @"E:\Mizans Research\Project\6Test.txt";
        //public static string InputFilePath = @"E:\Mizans Research\Project\SampleTest10.txt";
        //public static string InputFilePath = @"E:\Mizans Research\Project\SampleTest7.txt";
        public static string OutputFilePath = @"E:\Mizans Research\Project\Output.txt";
    }
}
