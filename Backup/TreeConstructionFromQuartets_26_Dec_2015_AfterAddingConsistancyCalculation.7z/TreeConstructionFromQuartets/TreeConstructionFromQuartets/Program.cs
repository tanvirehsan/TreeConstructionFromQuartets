﻿

namespace TreeConstructionFromQuartets
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using TreeConstructionFromQuartets.Model;

    public class Program
    {


        static void Main(string[] args)
        { 
            ConsistancyCalculation obj = new ConsistancyCalculation();
            obj.CalculateConsistancy();

        } 

    }
}
