﻿namespace TreeConstructionFromQuartets
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using TreeConstructionFromQuartets.Model;
    public class ConsistancyCalculation
    {
        private List<string> _VALID_TAXA_LIST = new List<string>();
        private List<Quartet> _DifferedQuatretListAfterGain = new List<Quartet>();
        private List<Quartet> _IsolatedQuatretListAfterGain = new List<Quartet>();



        public string DummyTaxaCharacter = "A";
        public void CalculateConsistancy()
        {

            if (File.Exists(Constant.OutputFilePath))
            {
                File.Delete(Constant.OutputFilePath);
            }
            DivideAndConquer divideAndConquer = new DivideAndConquer();
            InputProcessing input = new InputProcessing();
            Bipartition bp = new Bipartition(input);
            GainTable GainTable = new GainTable();
            GainTable = bp.getFinalGainTable();

            List<ConsistencyDataModel> ListConsistencyDataModel = new List<ConsistencyDataModel>();
            int loop = 0;
            ConsistencyDataModel data = new ConsistencyDataModel();
            DepthOneTreeNode node;
            List<DepthOneTreeNode> ListDepthOneTreeNode = new List<DepthOneTreeNode>();


            if (GainTable != null)
            {
                PartitionSet setOfMaxGain = GainTable.PartitionSet;
                var vDiffered = setOfMaxGain._ListQuatrets.FindAll(x => x._PartitionStatus == PartitionStatus.Differed);
                if (vDiffered != null)
                    SetDifferedQuatretInput(vDiffered.ToList());
                var vIsolated = setOfMaxGain._ListQuatrets.FindAll(x => x._PartitionStatus == PartitionStatus.Isolated);
                if (vIsolated != null)
                    SetIsolatedQuatretInput(vIsolated.ToList());

                OutputProcessing.PrintGainSummary(GainTable);
                OutputProcessing.WriteCountInformationFromMaxGainTable(GainTable);


                _VALID_TAXA_LIST = input.Get_SetOfTaxa();
                divideAndConquer.Divide(GainTable.PartitionSet, DummyTaxaCharacter, 1, _VALID_TAXA_LIST);
                List<FinalPartionPair> ll = divideAndConquer.getFinalPartionPair();
                OutputProcessing.PrintFinalTableOfDivideAndConquerApproach(ll);



                foreach (FinalPartionPair pair in ll)
                {
                    ListDepthOneTreeNode = new List<DepthOneTreeNode>();
                    data = new ConsistencyDataModel();
                    data._Differed_Quatret = this._DifferedQuatretListAfterGain;
                    data._Isolated_Quatret = this._IsolatedQuatretListAfterGain;

                    foreach (Taxa tx in pair._P.TaxaList)
                    {
                        node = new DepthOneTreeNode();
                        node._Position = loop;
                        node._Taxa_Value = tx._Taxa_Value;
                        ListDepthOneTreeNode.Add(node);
                    }
                    data._DepthOneChain = ListDepthOneTreeNode;
                    ListConsistencyDataModel.Add(data);
                    loop++;
                }



                // finding Consistancy Status

                ConsistencyDataModel dmodel = ListConsistencyDataModel[0];
                string OutputHeader = "======================================================Consistancy Calculation======================================================";
                dmodel._Isolated_Quatret = GetConsistancyStatusOfQuatret(ListConsistencyDataModel, dmodel._Isolated_Quatret);
                //var vIsoConsistent = dmodel._Isolated_Quatret.FindAll(x => x._ConsistancyStatus == ConsistencyStatus.Consistent);
                //var vIsoInConsistent = dmodel._Isolated_Quatret.FindAll(x => x._ConsistancyStatus == ConsistencyStatus.InConsistent);
                OutputProcessing.WriteQuatretConsistancy(dmodel._Isolated_Quatret, PartitionStatus.Isolated, OutputHeader);

                dmodel._Differed_Quatret = GetConsistancyStatusOfQuatret(ListConsistencyDataModel, dmodel._Differed_Quatret);
                //var vDiffConsistent = dmodel._Differed_Quatret.FindAll(x => x._ConsistancyStatus == ConsistencyStatus.Consistent);
                //var vDiffInConsistent = dmodel._Differed_Quatret.FindAll(x => x._ConsistancyStatus == ConsistencyStatus.InConsistent);
                OutputProcessing.WriteQuatretConsistancy(dmodel._Differed_Quatret, PartitionStatus.Differed, string.Empty);


            }

        }

        public void SetDifferedQuatretInput(List<Quartet> Q)
        {

            this._DifferedQuatretListAfterGain = new List<Quartet>(Q.Select(m => new Quartet()
            {

                _First_Taxa_Value = m._First_Taxa_Value,
                _Second_Taxa_Value = m._Second_Taxa_Value,
                _Third_Taxa_Value = m._Third_Taxa_Value,
                _Fourth_Taxa_Value = m._Fourth_Taxa_Value,
                _Quartet_Name = m._Quartet_Name,
                _Quartet_Input = m._Quartet_Input,
                _Quartet_LeftPart = m._Quartet_LeftPart,
                _Quartet_LeftPartReverse = m._Quartet_LeftPartReverse,
                _Quartet_RightPart = m._Quartet_RightPart,
                _Quartet_RightPartReverse = m._Quartet_RightPartReverse,
                _isDistinct = m._isDistinct,
                _Frequency = m._Frequency,
                _ConsistancyStatus = m._ConsistancyStatus,
                _PartitionStatus = m._PartitionStatus

            }));
        }

        public void SetIsolatedQuatretInput(List<Quartet> Q)
        {
            this._IsolatedQuatretListAfterGain = new List<Quartet>(Q.Select(m => new Quartet()
            {

                _First_Taxa_Value = m._First_Taxa_Value,
                _Second_Taxa_Value = m._Second_Taxa_Value,
                _Third_Taxa_Value = m._Third_Taxa_Value,
                _Fourth_Taxa_Value = m._Fourth_Taxa_Value,
                _Quartet_Name = m._Quartet_Name,
                _Quartet_Input = m._Quartet_Input,
                _Quartet_LeftPart = m._Quartet_LeftPart,
                _Quartet_LeftPartReverse = m._Quartet_LeftPartReverse,
                _Quartet_RightPart = m._Quartet_RightPart,
                _Quartet_RightPartReverse = m._Quartet_RightPartReverse,
                _isDistinct = m._isDistinct,
                _Frequency = m._Frequency,
                _ConsistancyStatus = m._ConsistancyStatus,
                _PartitionStatus = m._PartitionStatus

            }));
        }
        public List<Quartet> GetConsistancyStatusOfQuatret(List<ConsistencyDataModel> _DepthOneChain, List<Quartet> input)
        {


            int pos1 = 0;
            int pos2 = 0;
            int pos3 = 0;
            int pos4 = 0;
            foreach (Quartet q in input)
            {
                q._ConsistancyStatus = ConsistencyStatus.None;

                pos1 = getPosition(_DepthOneChain, q._First_Taxa_Value);
                pos2 = getPosition(_DepthOneChain, q._Second_Taxa_Value);
                pos3 = getPosition(_DepthOneChain, q._Third_Taxa_Value);
                pos4 = getPosition(_DepthOneChain, q._Fourth_Taxa_Value);

                if (pos1 != -1 && pos2 != -1 && pos3 != -1 && pos4 != -1)
                {
                    if (pos2 >= pos1 && pos3 >= pos2 && pos4 >= pos1)
                    {
                        q._ConsistancyStatus = ConsistencyStatus.Consistent;
                    }
                    else
                    {
                        q._ConsistancyStatus = ConsistencyStatus.InConsistent;

                    }
                }
                else
                {
                    q._ConsistancyStatus = ConsistencyStatus.InConsistent;

                }

            }



            return new List<Quartet>(input.Select(m => new Quartet()
            {

                _First_Taxa_Value = m._First_Taxa_Value,
                _Second_Taxa_Value = m._Second_Taxa_Value,
                _Third_Taxa_Value = m._Third_Taxa_Value,
                _Fourth_Taxa_Value = m._Fourth_Taxa_Value,
                _Quartet_Name = m._Quartet_Name,
                _Quartet_Input = m._Quartet_Input,
                _Quartet_LeftPart = m._Quartet_LeftPart,
                _Quartet_LeftPartReverse = m._Quartet_LeftPartReverse,
                _Quartet_RightPart = m._Quartet_RightPart,
                _Quartet_RightPartReverse = m._Quartet_RightPartReverse,
                _isDistinct = m._isDistinct,
                _Frequency = m._Frequency,
                _ConsistancyStatus = m._ConsistancyStatus,
                _PartitionStatus = m._PartitionStatus

            }));
        }

        public int getPosition(List<ConsistencyDataModel> ListConsistencyDataModel, string taxa)
        {
            int position = -1;

            foreach (ConsistencyDataModel model in ListConsistencyDataModel)
            {
                var v = model._DepthOneChain.FindAll(x => x._Taxa_Value == taxa).FirstOrDefault();
                if (v != null)
                {
                    position = v._Position;
                    break;
                }
                else
                {
                    position = -1;
                }
            }


            return position;


        }
    }
}
