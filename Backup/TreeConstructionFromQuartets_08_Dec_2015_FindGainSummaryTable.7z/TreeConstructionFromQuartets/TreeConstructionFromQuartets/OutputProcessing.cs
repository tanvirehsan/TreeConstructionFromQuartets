﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TreeConstructionFromQuartets.Model;

namespace TreeConstructionFromQuartets
{
    public class OutputProcessing
    {

        public static void PrintGainSummary(List<GainTable> _TaxaGainTable)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("======================================================Gain Summary======================================================");
            int count = 0;
            int tableIndex = 1;
            foreach (GainTable ttm in _TaxaGainTable)
            {
                count = 0;
                foreach (Taxa tt in ttm._TaxaGainSummary)
                {
                    if (count == 0)
                    {
                        sb.AppendLine("Table :" + tableIndex.ToString());
                        sb.AppendLine("------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        sb.AppendLine("                " + "K" + "                " + "                " + "Taxon" + "                " + "                " + "Gain" + "                " + "                " + "CGain" + "                ");
                        sb.AppendLine("-----------------------------------------------------------------------------------------------------------------------------------------------------------");

                        sb.AppendLine("                " + (tt.StepK + 1).ToString() + "                " + "                " + tt._Taxa_Value + "                " + "                " + tt._Gain + "                " + "                " + tt._CumulativeGain + "                ");
                    }
                    else
                    {
                        sb.AppendLine("                " + (tt.StepK + 1).ToString() + "                " + "                " + tt._Taxa_Value + "                " + "                " + tt._Gain + "                " + "                " + tt._CumulativeGain + "                ");
                    }

                    count++;
                }

                tableIndex++;

            }

            // System.Console.WriteLine(sb.ToString());
            //System.Console.ReadLine();
            File.WriteAllText(Constant.OutputFilePath, sb.ToString());
        }

        
        public static void WriteInititalBiPartion(List<PartitionSet> PartitionSets, List<int> Set_Of_Taxa)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("----------------Set Of Taxa-----------------");
            string SetOfTaxa = "P={";
            foreach (int tx in Set_Of_Taxa)
            {
                SetOfTaxa = SetOfTaxa + tx.ToString() + ",";

            }
            SetOfTaxa = SetOfTaxa.Substring(0, SetOfTaxa.Length - 1);

            sb.AppendLine(SetOfTaxa + "}");


            sb.AppendLine("----------------Set Of Quatret-----------------");
            string SetOfQuatrets = "Q={";
            foreach (Quartet tx in PartitionSets[0]._ListQuatrets)
            {
                SetOfQuatrets = SetOfQuatrets + "((" + tx._First_Taxa_Value.ToString() + "," + tx._Second_Taxa_Value.ToString() + "),(" + tx._Third_Taxa_Value.ToString() + "," + tx._Fourth_Taxa_Value.ToString() + "));";

            }
            SetOfQuatrets = SetOfQuatrets.Substring(0, SetOfQuatrets.Length - 1);

            sb.AppendLine(SetOfQuatrets + "}");


            sb.AppendLine("----------------Initial Bipartition-----------------");
            string InitialBiPart = string.Empty;
            int ii = 0;
            foreach (PartitionSet set in PartitionSets)
            {

                foreach (Partition part in set.PartitionList)
                {
                    InitialBiPart = InitialBiPart + "P" + part._PartitionName + "={";

                    foreach (Taxa t in part.TaxaList)
                    {
                        InitialBiPart = InitialBiPart + t._Taxa_Value.ToString() + ",";
                    }
                    InitialBiPart = InitialBiPart.Substring(0, InitialBiPart.Length - 1);
                    InitialBiPart = InitialBiPart + "}";
                    sb.AppendLine(InitialBiPart);
                    InitialBiPart = string.Empty;
                }


                sb.AppendLine("----------------Set Of Satisfied-----------------");
                SetOfQuatrets = "Satisfied: (" + set._SatisfiedCount.ToString() + ")={";
                foreach (Quartet tx in set._ListQuatrets)
                {
                    if (tx._PartitionStatus == PartitionStatus.Satisfied)
                        SetOfQuatrets = SetOfQuatrets + "((" + tx._First_Taxa_Value.ToString() + "," + tx._Second_Taxa_Value.ToString() + "),(" + tx._Third_Taxa_Value.ToString() + "," + tx._Fourth_Taxa_Value.ToString() + "));";

                }
                SetOfQuatrets = SetOfQuatrets.Substring(0, SetOfQuatrets.Length - 1);

                if (set._SatisfiedCount != 0)
                    sb.AppendLine(SetOfQuatrets + "}");
                else
                    sb.AppendLine(SetOfQuatrets);




                sb.AppendLine("----------------Set Of Violated-----------------");
                SetOfQuatrets = "Viotated : (" + set._ViotatedCount.ToString() + ")={";
                foreach (Quartet tx in set._ListQuatrets)
                {
                    if (tx._PartitionStatus == PartitionStatus.Viotated)
                        SetOfQuatrets = SetOfQuatrets + "((" + tx._First_Taxa_Value.ToString() + "," + tx._Second_Taxa_Value.ToString() + "),(" + tx._Third_Taxa_Value.ToString() + "," + tx._Fourth_Taxa_Value.ToString() + "));";

                }
                SetOfQuatrets = SetOfQuatrets.Substring(0, SetOfQuatrets.Length - 1);

                if (set._ViotatedCount != 0)
                    sb.AppendLine(SetOfQuatrets + "}");
                else
                    sb.AppendLine(SetOfQuatrets);


                sb.AppendLine("----------------Set Of Differed-----------------");
                SetOfQuatrets = "Differed : (" + set._DifferedCount.ToString() + ")={";
                foreach (Quartet tx in set._ListQuatrets)
                {
                    if (tx._PartitionStatus == PartitionStatus.Differed)
                        SetOfQuatrets = SetOfQuatrets + "((" + tx._First_Taxa_Value.ToString() + "," + tx._Second_Taxa_Value.ToString() + "),(" + tx._Third_Taxa_Value.ToString() + "," + tx._Fourth_Taxa_Value.ToString() + "));";

                }
                SetOfQuatrets = SetOfQuatrets.Substring(0, SetOfQuatrets.Length - 1);

                if (set._DifferedCount != 0)
                    sb.AppendLine(SetOfQuatrets + "}");
                else
                    sb.AppendLine(SetOfQuatrets);


                sb.AppendLine("----------------Set Of Isolated-----------------");
                SetOfQuatrets = "Isolated : (" + set._IsolatedCount.ToString() + ")={";
                foreach (Quartet tx in set._ListQuatrets)
                {
                    if (tx._PartitionStatus == PartitionStatus.Isolated)
                        SetOfQuatrets = SetOfQuatrets + "((" + tx._First_Taxa_Value.ToString() + "," + tx._Second_Taxa_Value.ToString() + "),(" + tx._Third_Taxa_Value.ToString() + "," + tx._Fourth_Taxa_Value.ToString() + "));";

                }
                SetOfQuatrets = SetOfQuatrets.Substring(0, SetOfQuatrets.Length - 1);

                if (set._IsolatedCount != 0)
                    sb.AppendLine(SetOfQuatrets + "}");
                else
                    sb.AppendLine(SetOfQuatrets);

                sb.AppendLine("----------------Score Calculation-----------------");
                if (ii == 0)
                {
                    sb.AppendLine("Initial Score: (" + set._Final_Score.ToString() + ")");
                }
                else
                {
                    sb.AppendLine("Gain Of: (" + set._taxValueForGainCalculation.ToString() + ")");
                    sb.AppendLine("Final Score: (" + set._Final_Score.ToString() + ")");
                    sb.AppendLine("Gain Score: (" + (set._Final_Score - PartitionSets[0]._Final_Score).ToString() + ")");

                }
                sb.AppendLine("----------------End OF " + set._PartitionSetName);
                ii++;
            }

            //System.Console.WriteLine(sb.ToString());
            //System.Console.ReadLine();
            File.WriteAllText(Constant.OutputFilePath, sb.ToString());
        }


    }

}
