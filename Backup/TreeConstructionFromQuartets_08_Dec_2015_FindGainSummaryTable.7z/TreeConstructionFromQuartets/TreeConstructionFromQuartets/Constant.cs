﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TreeConstructionFromQuartets
{
    public class Constant
    {
        //public static string InputFilePath = @"E:\Mizans Research\Project\10Test.txt";
        //public static string InputFilePath = @"E:\Mizans Research\Project\6Test.txt";
        public static string InputFilePath = @"E:\Mizans Research\Project\1000Test.txt";
        public static string OutputFilePath =@"E:\Mizans Research\Project\Output.txt";
    }
}
