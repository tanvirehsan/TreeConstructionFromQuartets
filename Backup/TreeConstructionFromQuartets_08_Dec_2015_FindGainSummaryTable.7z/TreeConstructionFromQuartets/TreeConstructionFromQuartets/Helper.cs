﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TreeConstructionFromQuartets.Model;

namespace TreeConstructionFromQuartets
{
    public class Helper
    {

        public static int getFirstTaxaValue(string taxInput)
        {
            int LastIndexOf = taxInput.LastIndexOf("(") + 1;
            string val = taxInput.Substring(LastIndexOf  );
            return Convert.ToInt32(val);
        }

        public static int getSecondTaxaValue(string taxInput)
        {
            int LastIndexOf = taxInput.IndexOf(")")  ;
            string val = taxInput.Substring(0,LastIndexOf);
            return Convert.ToInt32(val);
        }

        //public static int getThirdTaxaValue(string taxInput)
        //{
        //    string val = taxInput.Substring(1 );
        //    return Convert.ToInt32(val);
        //}

        //public static int getFourthTaxaValue(string taxInput)
        //{
        //    string val = taxInput.Substring(0,taxInput.Length-3);
        //    return Convert.ToInt32(val);
        //}
    }
}
