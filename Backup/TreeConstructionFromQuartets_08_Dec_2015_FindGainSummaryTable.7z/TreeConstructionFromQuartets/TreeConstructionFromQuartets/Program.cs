﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TreeConstructionFromQuartets
{
    class Program
    {
        static void Main(string[] args)
        {
            InputProcessing input = new InputProcessing();
            input.Get_SetOfQuartets();
            input.Get_SetOfTaxa();
            Bipartition bp = new Bipartition(input);
        }
    }
}
