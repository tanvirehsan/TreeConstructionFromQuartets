﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TreeConstructionFromQuartets.Model
{
    public class GainSummary
    {
        public int _StepNumber { get; set; }
        public int _Taxon { get; set; }
        public int _Gain { get; set; }
        public int _CGain { get; set; }
        public int GainSummaryTableIndex { get; set; } 
        public PartitionSet PartitionSet { get; set; }
    }
}
