﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TreeConstructionFromQuartets.Model
{
    public class Quartet
    {
        public int _First_Taxa_Value { get; set; }
        public int _Second_Taxa_Value { get; set; }
        public int _Third_Taxa_Value { get; set; }
        public int _Fourth_Taxa_Value { get; set; }
        public string _Quartet_Name { get; set; }
        public string _Quartet_Input { get; set; }

        public string _Quartet_LeftPart { get; set; }
        public string _Quartet_LeftPartReverse { get; set; }

        public string _Quartet_RightPart { get; set; }

        public string _Quartet_RightPartReverse { get; set; }

        public bool _isDistinct { get; set; }


        public int _Frequency { get; set; }


        private List<string> DuplicateQuatrets = new List<string>();
        public List<string> _DuplicateQuatrets  
        {
            get  
            {

                return DuplicateQuatrets;
            }
            set  
            {
                DuplicateQuatrets = value;
            }
        }

        public PartitionStatus _PartitionStatus { get; set; }


    }
}
