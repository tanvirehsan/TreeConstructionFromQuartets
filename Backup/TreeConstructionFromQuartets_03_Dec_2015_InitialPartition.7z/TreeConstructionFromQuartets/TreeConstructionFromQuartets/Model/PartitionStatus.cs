﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TreeConstructionFromQuartets.Model
{
    public enum PartitionStatus
    {
        Satisfied,
        Viotated,
        Differed,
        Isolated,
        None
    };
}
