﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TreeConstructionFromQuartets.Model
{
    public class PartitionSet
    {

        public PartitionSet(string PartitionSetName)
        {

            this._PartitionSetName = PartitionSetName;
        }
        public string _PartitionSetName { get; set; }



        public int _IsolatedCount { get; set; }
        public int _ViotatedCount { get; set; }
        public int _DifferedCount { get; set; }
        public int _SatisfiedCount { get; set; }


        private List<Partition> _PartitionList = new List<Partition>();
        public List<Partition> PartitionList
        {
            get
            {

                return _PartitionList;
            }
            set
            {
                _PartitionList = value;
            }
        }
    }
}
