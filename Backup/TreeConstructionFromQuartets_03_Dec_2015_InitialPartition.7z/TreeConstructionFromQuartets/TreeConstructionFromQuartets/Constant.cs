﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TreeConstructionFromQuartets
{
    public class Constant
    {
        public static string InputFilePath = @"E:\Mizans Research\Project\InputNew.txt";
        public static string OutputFilePath =@"E:\Mizans Research\Project\Output.txt";
    }
}
