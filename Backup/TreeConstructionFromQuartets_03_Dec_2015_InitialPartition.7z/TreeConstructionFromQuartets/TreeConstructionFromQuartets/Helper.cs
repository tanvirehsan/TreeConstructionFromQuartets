﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TreeConstructionFromQuartets.Model;

namespace TreeConstructionFromQuartets
{
    public class Helper
    {

        public static int getFirstTaxaValue(string taxInput)
        {
            string val = taxInput.Substring(taxInput.IndexOf("((") + 2);
            return Convert.ToInt32(val);
        }

        public static int getSecondTaxaValue(string taxInput)
        {
            string val = taxInput.Substring(0,taxInput.Length-1);
            return Convert.ToInt32(val);
        }

        public static int getThirdTaxaValue(string taxInput)
        {
            string val = taxInput.Substring(1 );
            return Convert.ToInt32(val);
        }

        public static int getFourthTaxaValue(string taxInput)
        {
            string val = taxInput.Substring(0,taxInput.Length-3);
            return Convert.ToInt32(val);
        }
    }
}
