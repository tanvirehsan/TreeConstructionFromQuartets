﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TreeConstructionFromQuartets.Model;

namespace TreeConstructionFromQuartets
{
    public class Bipartition
    {
        private List<Quartet> Set_Of_Quartets = new List<Quartet>();
        private List<Quartet> Set_Of_Distinct_Quartets = new List<Quartet>();

        private List<Quartet> Set_Of_Duplicate_Quartets = new List<Quartet>();
        private List<Quartet> Set_Of_DistinctDuplicate_Quartets = new List<Quartet>();

        private List<Quartet> Set_Of_Sorted_Distinct_Quartets = new List<Quartet>();
        private List<int> Set_Of_Taxa = new List<int>();
        private InputProcessing inputData;



        public Bipartition(InputProcessing input)
        {
            this.inputData = input;
            this.Set_Of_Quartets = inputData.Get_SetOfQuartets();
            this.Set_Of_Taxa = inputData.Get_SetOfTaxa();
            SetDistinctQuartets();
            SetDistinctDuplicateQuartets();
            SetDistinctQuartetsAfterAddingDuplicateQuartets();
            SetSortedDistinctQuartets();
            InitialBipartition(0);
            SetSortedDistinctQuartetsWithPartitionStatus();
            SetSummaryCount();
            OutputProcessing.WriteInititalBiPartion(this.Set_Of_Sorted_Distinct_Quartets, this.PartitionSets, this.Set_Of_Taxa);
        }
        public void SetSortedDistinctQuartetsWithPartitionStatus()
        {
            foreach (Quartet q in Set_Of_Sorted_Distinct_Quartets)
            {
                foreach (PartitionSet set in this.PartitionSets)
                {

                    q._PartitionStatus = getPartitionStatus(q, set);


                }
            }
        }
        public void SetSummaryCount()
        {
            foreach (PartitionSet set in this.PartitionSets)
            {
                var IsolatedCount = this.Set_Of_Sorted_Distinct_Quartets.Where(x => x._PartitionStatus == PartitionStatus.Isolated).Count();
                var ViotatedCount = this.Set_Of_Sorted_Distinct_Quartets.Where(x => x._PartitionStatus == PartitionStatus.Viotated).Count();
                var DifferedCount = this.Set_Of_Sorted_Distinct_Quartets.Where(x => x._PartitionStatus == PartitionStatus.Differed).Count();
                var SatisfiedCount = this.Set_Of_Sorted_Distinct_Quartets.Where(x => x._PartitionStatus == PartitionStatus.Satisfied).Count();


                set._IsolatedCount = IsolatedCount;
                set._ViotatedCount = ViotatedCount;
                set._DifferedCount = DifferedCount;
                set._SatisfiedCount = SatisfiedCount;
            }


        }
        public void SetSortedDistinctQuartets()
        {
            var list = from element in Set_Of_Distinct_Quartets
                       orderby element._Frequency descending
                       select element;
            Set_Of_Sorted_Distinct_Quartets = new List<Quartet>(list);
        }

        public void SetDistinctQuartetsAfterAddingDuplicateQuartets()
        {
            foreach (Quartet objQuartetInner in Set_Of_DistinctDuplicate_Quartets)
            {
                Set_Of_Distinct_Quartets.Add(objQuartetInner);
            }
        }

        public void SetDistinctQuartets()
        {
            int count = 0;
            List<string> _Quatret = new List<string>();
            foreach (Quartet objQuartet in Set_Of_Quartets)
            {
                count = 0;
                _Quatret = new List<string>();
                foreach (Quartet objQuartetInner in Set_Of_Quartets)
                {
                    if (objQuartet._Quartet_Name != objQuartetInner._Quartet_Name)
                    {
                        if (CheckValue(objQuartet._Quartet_LeftPart, objQuartet._Quartet_RightPart, objQuartetInner._Quartet_LeftPart, objQuartetInner._Quartet_LeftPartReverse, objQuartetInner._Quartet_RightPart, objQuartetInner._Quartet_RightPartReverse))
                        {

                            count++;
                            _Quatret.Add(objQuartetInner._Quartet_Name);
                        }

                    }

                }
                objQuartet._Frequency = count + 1;
                if (count == 0)
                {
                    objQuartet._isDistinct = true;
                    Set_Of_Distinct_Quartets.Add(objQuartet);
                }
                else
                {
                    objQuartet._isDistinct = false;
                    objQuartet._DuplicateQuatrets = _Quatret;


                    Set_Of_Duplicate_Quartets.Add(objQuartet);
                }

            }



        }

        public void SetDistinctDuplicateQuartets()
        {


            for (int i = 0; i < Set_Of_Duplicate_Quartets.Count; i++)
            {
                var findQuatret = Set_Of_Duplicate_Quartets[i];
                var findQuatretName = findQuatret._Quartet_Name;

                if (i == 0)
                {
                    Set_Of_DistinctDuplicate_Quartets.Add(findQuatret);
                }
                else
                {

                    if (isNotExistInDistinctDuplicate(findQuatret))
                    {
                        Set_Of_DistinctDuplicate_Quartets.Add(findQuatret);
                    }

                }
            }
        }

        public bool isNotExistInDistinctDuplicate(Quartet findQuatret)
        {
            int count = 0;
            for (int k = 0; k < Set_Of_DistinctDuplicate_Quartets.Count; k++)
            {
                var CurrQuatret = Set_Of_DistinctDuplicate_Quartets[k];

                if (findQuatret._Quartet_Name != CurrQuatret._Quartet_Name)
                {
                    if (CheckValue(findQuatret._Quartet_LeftPart, findQuatret._Quartet_RightPart, CurrQuatret._Quartet_LeftPart, CurrQuatret._Quartet_LeftPartReverse, CurrQuatret._Quartet_RightPart, CurrQuatret._Quartet_RightPartReverse))
                    {

                        count++;

                    }
                }
            }
            if (count == 0)
                return true;
            return false;

        }

        public bool CheckValue(string _Quartet_LeftPart, string _Quartet_RightPart, string InnerQuartet_LeftPart, string InnerQuartet_LeftPartReverse, string InnerQuartet_RightPart, string InnerQuartet_RightPartReverse)
        {
            if (

                                       (_Quartet_LeftPart.Equals(InnerQuartet_LeftPart) ||
                                       _Quartet_LeftPart.Equals(InnerQuartet_LeftPartReverse) ||
                                       _Quartet_LeftPart.Equals(InnerQuartet_RightPart) ||
                                       _Quartet_LeftPart.Equals(InnerQuartet_RightPartReverse)
                                       )
                                       &&
                                       (_Quartet_RightPart.Equals(InnerQuartet_LeftPart) ||
                                       _Quartet_RightPart.Equals(InnerQuartet_LeftPartReverse) ||
                                       _Quartet_RightPart.Equals(InnerQuartet_RightPart) ||
                                       _Quartet_RightPart.Equals(InnerQuartet_RightPartReverse)
                                       )

                                       )
            {

                return true;

            }

            return false;
        }

        public List<Quartet> getSetOfSortedDistinctQuartets()
        {
            return this.Set_Of_Sorted_Distinct_Quartets;
        }


        private List<PartitionSet> PartitionSets = new List<PartitionSet>();

        public void InitialBipartition(int PartitionSetNo)
        {
            PartitionSet Partition = new PartitionSet("Partition" + PartitionSetNo.ToString());
            List<Partition> Partitions = new List<Partition>();

            Partition _PartitionA;
            Partition _PartitionB;
            int index = 0;
            _PartitionA = new Partition("A" + index.ToString());
            _PartitionB = new Partition("B" + index.ToString());

            List<int> SetOfTaxa = new List<int>(this.Set_Of_Taxa);


            int t1 = 0;
            int t2 = 0;
            int t3 = 0;
            int t4 = 0;


            foreach (Quartet q in Set_Of_Sorted_Distinct_Quartets)
            {
                t1 = q._First_Taxa_Value;
                t2 = q._Second_Taxa_Value;
                t3 = q._Third_Taxa_Value;
                t4 = q._Fourth_Taxa_Value;
                var Qurtet_Name = q._Quartet_Name;

                if (!CheckForNoneOfTheValuesBelongTo(q._Quartet_Name, _PartitionA, _PartitionB, q._First_Taxa_Value, q._Second_Taxa_Value, q._Third_Taxa_Value, q._Fourth_Taxa_Value))
                {
                    // If none of the 4 taxa belongs to either PartitionSet then Insert t1 and t2 in Pa0 and t3 and t4 in Pb0
                    _PartitionA.TaxaList.Add(GetTaxa(t1, Qurtet_Name, 0));
                    SetOfTaxa.Remove(t1);
                    _PartitionA.TaxaList.Add(GetTaxa(t2, Qurtet_Name, 1));
                    SetOfTaxa.Remove(t2);
                    _PartitionB.TaxaList.Add(GetTaxa(t3, Qurtet_Name, 2));
                    SetOfTaxa.Remove(t3);
                    _PartitionB.TaxaList.Add(GetTaxa(t4, Qurtet_Name, 3));
                    SetOfTaxa.Remove(t4);
                }
                else
                {


                    //  insert t1
                    if (!isBelongToPartition(_PartitionA, t1) && !isBelongToPartition(_PartitionB, t1))
                    {
                        if (isBelongToPartition(_PartitionA, t2))
                        {
                            _PartitionA.TaxaList.Add(GetTaxa(t1, Qurtet_Name, 0));
                            SetOfTaxa.Remove(t1);
                        }
                        else if (isBelongToPartition(_PartitionB, t2))
                        {
                            _PartitionB.TaxaList.Add(GetTaxa(t1, Qurtet_Name, 0));
                            SetOfTaxa.Remove(t1);
                        }
                        else
                        {
                            if (isBelongToPartition(_PartitionA, t3))
                            {
                                _PartitionB.TaxaList.Add(GetTaxa(t1, Qurtet_Name, 0));
                                SetOfTaxa.Remove(t1);
                            }
                            else if (isBelongToPartition(_PartitionB, t3))
                            {
                                _PartitionA.TaxaList.Add(GetTaxa(t1, Qurtet_Name, 0));
                                SetOfTaxa.Remove(t1);
                            }
                            else
                            {
                                if (isBelongToPartition(_PartitionA, t4))
                                {
                                    _PartitionB.TaxaList.Add(GetTaxa(t1, Qurtet_Name, 0));
                                    SetOfTaxa.Remove(t1);
                                }
                                else if (isBelongToPartition(_PartitionB, t4))
                                {
                                    _PartitionA.TaxaList.Add(GetTaxa(t1, Qurtet_Name, 0));
                                    SetOfTaxa.Remove(t1);
                                }
                            }
                        }

                    }
                    //insert t2
                    else if (!isBelongToPartition(_PartitionA, t2) && !isBelongToPartition(_PartitionB, t2))
                    {
                        if (isBelongToPartition(_PartitionA, t1))
                        {
                            _PartitionA.TaxaList.Add(GetTaxa(t2, Qurtet_Name, 1));
                            SetOfTaxa.Remove(t2);
                        }
                        else if (isBelongToPartition(_PartitionB, t1))
                        {
                            _PartitionB.TaxaList.Add(GetTaxa(t2, Qurtet_Name, 1));
                            SetOfTaxa.Remove(t2);
                        }
                    }

                    //insert t3
                    else if (!isBelongToPartition(_PartitionA, t3) && !isBelongToPartition(_PartitionB, t3))
                    {
                        if (isBelongToPartition(_PartitionA, t4))
                        {
                            _PartitionA.TaxaList.Add(GetTaxa(t3, Qurtet_Name, 2));
                            SetOfTaxa.Remove(t3);
                        }
                        else if (isBelongToPartition(_PartitionB, t4))
                        {
                            _PartitionB.TaxaList.Add(GetTaxa(t3, Qurtet_Name, 2));
                            SetOfTaxa.Remove(t3);
                        }
                        else
                        {
                            if (isBelongToPartition(_PartitionA, t1))
                            {
                                // Add t3 to _PartitionB
                                _PartitionB.TaxaList.Add(GetTaxa(t3, Qurtet_Name, 2));
                                SetOfTaxa.Remove(t3);
                            }
                            else if (isBelongToPartition(_PartitionB, t1))
                            {
                                // Add t3 to _PartitionA
                                _PartitionA.TaxaList.Add(GetTaxa(t3, Qurtet_Name, 2));
                                SetOfTaxa.Remove(t3);
                            }
                            else if (isBelongToPartition(_PartitionA, t2))
                            {
                                // Add t3 to _PartitionB
                                _PartitionB.TaxaList.Add(GetTaxa(t3, Qurtet_Name, 2));
                                SetOfTaxa.Remove(t3);
                            }
                            else if (isBelongToPartition(_PartitionB, t2))
                            {
                                // Add t3 to _PartitionA
                                _PartitionA.TaxaList.Add(GetTaxa(t3, Qurtet_Name, 2));
                                SetOfTaxa.Remove(t3);
                            }
                        }
                    }
                    //insert t4
                    else if (!isBelongToPartition(_PartitionA, t4) && !isBelongToPartition(_PartitionB, t4))
                    {
                        if (isBelongToPartition(_PartitionA, t3))
                        {
                            _PartitionA.TaxaList.Add(GetTaxa(t4, Qurtet_Name, 3));
                            SetOfTaxa.Remove(t4);
                        }
                        else if (isBelongToPartition(_PartitionB, t3))
                        {
                            _PartitionB.TaxaList.Add(GetTaxa(t4, Qurtet_Name, 3));
                            SetOfTaxa.Remove(t4);
                        }
                    }

                }

                //if (SetOfTaxa.Count == 0)
                //  break;

            }

            //-------------Step 4 if SetOfTaxa Remains Non Empty then  add remaining taxa to either part randomly
            Random rnd = new Random();
            int number = rnd.Next(1, 1000);
            if (number % 2 == 0)
            {
                foreach (int ii in SetOfTaxa)
                {
                    _PartitionA.TaxaList.Add(GetTaxa(number, "", 0));
                }
            }
            else
            {
                foreach (int ii in SetOfTaxa)
                {
                    _PartitionB.TaxaList.Add(GetTaxa(number, "", 0));
                }
            }
            //----------------------------------------End of Step 4

            Partitions.Add(_PartitionA);
            Partitions.Add(_PartitionB);
            Partition.PartitionList = Partitions;
            PartitionSets.Add(Partition);

        }

        public bool CheckForNoneOfTheValuesBelongTo(string _Quartet_Name, Partition _PartitionA, Partition _PartitionB, int _First_Taxa_Value, int _Second_Taxa_Value, int _Third_Taxa_Value, int _Fourth_Taxa_Value)
        {
            bool isFound = false;


            if (isBelongToPartition(_PartitionA, _First_Taxa_Value))
            {
                isFound = true;
            }
            if (isBelongToPartition(_PartitionB, _First_Taxa_Value))
            {
                isFound = true;
            }
            else if (isBelongToPartition(_PartitionA, _Second_Taxa_Value))
            {
                isFound = true;
            }
            else if (isBelongToPartition(_PartitionB, _Second_Taxa_Value))
            {
                isFound = true;
            }
            else if (isBelongToPartition(_PartitionA, _Third_Taxa_Value))
            {
                isFound = true;
            }
            else if (isBelongToPartition(_PartitionB, _Third_Taxa_Value))
            {
                isFound = true;
            }
            else if (isBelongToPartition(_PartitionA, _Fourth_Taxa_Value))
            {
                isFound = true;
            }
            else if (isBelongToPartition(_PartitionB, _Fourth_Taxa_Value))
            {
                isFound = true;
            }
            else
            {
                isFound = false;


            }

            return isFound;

        }

        public Taxa GetTaxa(int value, string _Quartet_Name, int position)
        {

            Taxa taxa = new Taxa();
            taxa._Taxa_Value = value;
            taxa._Quartet_Name = _Quartet_Name;
            taxa._Taxa_ValuePosition_In_Quartet = position;

            return taxa;

        }

        private bool isBelongToPartition(Partition _Partition, int taxa)
        {
            var _Taxa_Value = _Partition.TaxaList.Find(x => x._Taxa_Value == taxa);
            if (_Taxa_Value != null)
            {
                return true;
            }
            return false;
        }


        #region PartitionStatus

        public PartitionStatus getPartitionStatus(Quartet q, PartitionSet p)
        {
            if (isSatisfied(q, p))
            {
                return PartitionStatus.Satisfied;
            }
            else if (isViolated(q, p))
            {
                return PartitionStatus.Viotated;
            }
            else if (isDiffered(q, p))
            {
                return PartitionStatus.Differed;
            }
            else if (isIsolated(q, p))
            {
                return PartitionStatus.Isolated;
            }
            return PartitionStatus.None;
        }

        public bool isDiffered(Quartet q, PartitionSet p)
        {
            int t1 = 0;
            int t2 = 0;
            int t3 = 0;
            int t4 = 0;
            t1 = q._First_Taxa_Value;
            t2 = q._Second_Taxa_Value;
            t3 = q._Third_Taxa_Value;
            t4 = q._Fourth_Taxa_Value;

            Partition PartitionA = p.PartitionList[0];
            Partition PartitionB = p.PartitionList[1];



            if (isInPart(PartitionA, t1) && isInPart(PartitionB, t2))
            {
                if (isInSamePart(PartitionA, t3, t4) || isInSamePart(PartitionB, t3, t4))
                    return true;

            }
            else if (isInPart(PartitionB, t1) && isInPart(PartitionA, t2))
            {

                if (isInSamePart(PartitionA, t3, t4) || isInSamePart(PartitionB, t3, t4))
                    return true;

            }
            if (isInPart(PartitionA, t3) && isInPart(PartitionB, t4))
            {

                if (isInSamePart(PartitionA, t1, t2) || isInSamePart(PartitionB, t1, t2))
                    return true;

            }
            else if (isInPart(PartitionB, t3) && isInPart(PartitionA, t4))
            {

                if (isInSamePart(PartitionA, t1, t2) || isInSamePart(PartitionB, t1, t2))
                    return true;

            }

            return false;

        }

        public bool isIsolated(Quartet q, PartitionSet p)
        {
            int t1 = 0;
            int t2 = 0;
            int t3 = 0;
            int t4 = 0;
            t1 = q._First_Taxa_Value;
            t2 = q._Second_Taxa_Value;
            t3 = q._Third_Taxa_Value;
            t4 = q._Fourth_Taxa_Value;

            Partition PartitionA = p.PartitionList[0];
            Partition PartitionB = p.PartitionList[1];



            if (isInPart(PartitionA, t1) && isInPart(PartitionA, t2) && isInPart(PartitionA, t3) && isInPart(PartitionA, t4))
            {

                return true;

            }
            else if (isInPart(PartitionB, t1) && isInPart(PartitionB, t2) && isInPart(PartitionB, t3) && isInPart(PartitionB, t4))
            {

                return true;

            }

            return false;

        }

        public bool isViolated(Quartet q, PartitionSet p)
        {
            int t1 = 0;
            int t2 = 0;
            int t3 = 0;
            int t4 = 0;
            t1 = q._First_Taxa_Value;
            t2 = q._Second_Taxa_Value;
            t3 = q._Third_Taxa_Value;
            t4 = q._Fourth_Taxa_Value;

            Partition PartitionA = p.PartitionList[0];
            Partition PartitionB = p.PartitionList[1];



            if ((isInPart(PartitionA, t1) && isInPart(PartitionB, t2)) || (isInPart(PartitionA, t2) && isInPart(PartitionB, t1)))
            {
                if ((isInPart(PartitionA, t2) && isInPart(PartitionB, t3)) || (isInPart(PartitionA, t3) && isInPart(PartitionB, t2)))
                {
                    return true;
                }
            }

            return false;

        }

        public bool isSatisfied(Quartet q, PartitionSet p)
        {
            int t1 = 0;
            int t2 = 0;
            int t3 = 0;
            int t4 = 0;
            t1 = q._First_Taxa_Value;
            t2 = q._Second_Taxa_Value;
            t3 = q._Third_Taxa_Value;
            t4 = q._Fourth_Taxa_Value;

            Partition PartitionA = p.PartitionList[0];
            Partition PartitionB = p.PartitionList[1];

            if (isInSamePart(PartitionA, t1, t2) && isInSamePart(PartitionB, t3, t4))
            {
                return true;
            }
            else if (isInSamePart(PartitionB, t1, t2) && isInSamePart(PartitionA, t3, t4))
            {
                return true;
            }
            return false;
        }

        public bool isInSamePart(Partition obj, int t1, int t2)
        {
            var f1 = obj.TaxaList.FindAll(x => x._Taxa_Value == t1);
            if (f1 != null)
            {
                var f2 = obj.TaxaList.FindAll(x => x._Taxa_Value == t2);
                if (f2 != null)
                {
                    if (f2.Count != 0)
                        return true;
                }
            }
            return false;
        }

        public bool isInPart(Partition obj, int t1)
        {
            var f1 = obj.TaxaList.FindAll(x => x._Taxa_Value == t1);
            if (f1 != null)
            {
                if (f1.Count != 0)
                    return true;

            }
            return false;
        }




        #endregion

    }
}
