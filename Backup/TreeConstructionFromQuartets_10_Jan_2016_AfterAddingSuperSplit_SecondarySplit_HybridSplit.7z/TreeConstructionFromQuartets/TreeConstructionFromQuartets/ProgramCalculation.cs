﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TreeConstructionFromQuartets.Model;

namespace TreeConstructionFromQuartets
{
    public class ProgramCalculation
    {
        public void StepByStep()
        {
            #region Step:1 Find Depth One Chain and Consistancy Calculation
            ConsistancyCalculation obj = new ConsistancyCalculation();
            obj.CalculateConsistancy();

            // Getting the GainTable After Initial Bipartition
            GainTable GB = obj.getFinalGainTableAfterGainCalculation();
            // Getting Partition with maximum Gained Taxa 
            PartitionSet SetP = GB.PartitionSet;

            // Getting Differred, Isolated And Violated Quatret Before Devide and Conquer
            List<Quartet> _DifferedQuatretListAfterGain = obj.getDifferedQuatretListAfterGain();
            List<Quartet> _IsolatedQuatretListAfterGain = obj.getIsolatedQuatretListAfterGain();
            List<Quartet> _ViolatedQuatretListAfterGain = obj.getViolatedQuatretListAfterGain();

            // Getting Depth One Chain After Devide And Conquer
            List<ConsistencyDataModel> _ListConsistencyDataModel = obj.getListConsistencyDataModel();

            // Getting Consistent and Inconsistent Quatret 
            List<Quartet> _DifferredConsistentAfterDevideAndConquer = obj.getDifferedQuatretConsistentAfterDevideAndConquer();
            List<Quartet> _IsolatedConsistentAfterDevideAndConquer = obj.getIsolatedQuatretConsistentAfterDevideAndConquer();

            List<Quartet> _IsolatedInConsistentAfterDevideAndConquer = obj.getIsolatedQuatretInConsistentAfterDevideAndConquer();
            List<Quartet> _DifferredInConsistentAfterDevideAndConquer = obj.getDifferedQuatretInConsistentAfterDevideAndConquer();

            #endregion

            #region Step:2 Calculate Super Split List using All Violated Quatret

            SplitCalculation objSplitCalculation = new SplitCalculation();
            SplitModel SuperSplit = new SplitModel();
            if (_ViolatedQuatretListAfterGain.Count != 0)
            {
                SuperSplit = objSplitCalculation.CalculateSuperSplit(_ViolatedQuatretListAfterGain);
                OutputProcessing.WriteSplitValues(SuperSplit, "Super Split");
            }

            #endregion

            #region Step:3 Calculate Secondary Split


            SplitModel SecondarySplit = new SplitModel();
            if (_ViolatedQuatretListAfterGain.Count != 0)
            {
                SecondarySplit = objSplitCalculation.CalculateSecondarySplit(SetP, SuperSplit);
                OutputProcessing.WriteSplitValues(SecondarySplit, "Secondary Split");
            }

            #endregion

            #region Step:4 Calculate HyBrid Split

            SplitModel HybridSplit = new SplitModel();
            List<Quartet> ListInConsistantQuatretsTotal = new List<Quartet>();

            // Get all Insistent Quartet = Differred Inconsistent Quartet + Isolated Inconsistant Quartet
            var allInConsistentQuartet = _DifferredInConsistentAfterDevideAndConquer.Union(_IsolatedInConsistentAfterDevideAndConquer).ToList();

            ListInConsistantQuatretsTotal = allInConsistentQuartet;

            if (ListInConsistantQuatretsTotal.Count != 0)
            {
                HybridSplit = objSplitCalculation.CalculateHyBridSplit(SetP, SecondarySplit, ListInConsistantQuatretsTotal);
                OutputProcessing.WriteSplitValues(HybridSplit, "Hybrid Split");
            }

            #endregion
        }
    }
}
