﻿namespace TreeConstructionFromQuartets
{
    using System;
    public class Constant
    {
        public static string InputFilePath = @"E:\Mizans Research\Project\6Test.txt";
        public static string OutputFilePath = @"E:\Mizans Research\Project\Output.txt";
    }
}
