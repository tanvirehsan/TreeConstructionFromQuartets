﻿namespace TreeConstructionFromQuartets.Model
{
    using System;
    using System.Collections.Generic;
 
    public class PartitionSet
    {

        public PartitionSet(string PartitionSetName)
        {

            this._PartitionSetName = PartitionSetName;

            this._Final_Score = 0;
            this._IsolatedCount = 0;
            this._ViotatedCount = 0;
            this._SatisfiedCount = 0;
            this._DifferedCount = 0;
            this._taxValueForGainCalculation = 0;
            this._Gain = 0; 
            this.PartitionList = new List<Partition>();
            this._ListQuatrets = new List<Quartet>();
        }
        public string _PartitionSetName { get; set; }

        public int _taxValueForGainCalculation { get; set; }


        public int _Gain { get; set; }

        public int _Final_Score { get; set; }

        public int _IsolatedCount { get; set; }
        public int _ViotatedCount { get; set; }
        public int _DifferedCount { get; set; }
        public int _SatisfiedCount { get; set; }

        public List<Quartet> _ListQuatrets { get; set; }
        private List<Partition> _PartitionList = new List<Partition>();
        public List<Partition> PartitionList
        {
            get
            {

                return _PartitionList;
            }
            set
            {
                _PartitionList = value;
            }
        }
    }
}
