﻿namespace TreeConstructionFromQuartets.Model
{
    using System;
    using System.Collections.Generic;
 

    public enum PartitionStatus
    {   
        None,
        Satisfied,
        Viotated,
        Differed,
        Isolated,
        
    };
}
