﻿namespace TreeConstructionFromQuartets
{
    using System;
    using System.Collections.Generic;
    public class Program
    {
        static void Main(string[] args)
        {
            ProgramCalculation obj = new ProgramCalculation();
            //obj.StepByStep();
            obj.QuatretComparisonTechnique();
        }

    }
}
