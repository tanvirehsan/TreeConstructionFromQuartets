﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TreeConstructionFromQuartets.Model;

namespace TreeConstructionFromQuartets
{
    public class SplitCalculation
    {

        private List<SplitModel> FinalSplit = new List<SplitModel>();

        public void GetFinalSplitCalculation(List<Quartet> _listOfViolatedQuatret, SplitModel Model, int countTotalInConsistentQuatret)
        {
            List<Quartet> listOfViolatedQuatret = new List<Quartet>(_listOfViolatedQuatret);

            List<SplitModel> Split = new List<SplitModel>();
            SplitModel objSplitCurrent;
            Quartet CurrentInput = new Quartet();


            if (listOfViolatedQuatret.Count == 0)
            {
                SplitModel objModel = new SplitModel();
                objModel._LeftPartOfSplit = Model._LeftPartOfSplit;
                objModel._RightPartOfSplit = Model._RightPartOfSplit;
                objModel._LeftPartOfSplit.Sort();
                objModel._RightPartOfSplit.Sort();
                objModel._CountTaxa = objModel._LeftPartOfSplit.Count() + objModel._RightPartOfSplit.Count();
                FinalSplit.Add(objModel);
                return;
            }


            objSplitCurrent = new SplitModel();
            CurrentInput = listOfViolatedQuatret[0];
            objSplitCurrent._LeftPartOfSplit.Add(CurrentInput._First_Taxa_Value);
            objSplitCurrent._LeftPartOfSplit.Add(CurrentInput._Second_Taxa_Value);
            objSplitCurrent._RightPartOfSplit.Add(CurrentInput._Third_Taxa_Value);
            objSplitCurrent._RightPartOfSplit.Add(CurrentInput._Fourth_Taxa_Value);
            List<SplitModel> _splits;
            if (listOfViolatedQuatret.Count == countTotalInConsistentQuatret)
            {
                if (listOfViolatedQuatret.Count >= 1)
                    listOfViolatedQuatret.RemoveAt(0);
                GetFinalSplitCalculation(listOfViolatedQuatret, objSplitCurrent, countTotalInConsistentQuatret);
            }
            else
            {
                _splits = getSplitArrays(CurrentInput, Model);
                if (listOfViolatedQuatret.Count >= 1)
                    listOfViolatedQuatret.RemoveAt(0);

                if (_splits[0]._CountTaxa < _splits[1]._CountTaxa)
                {
                    GetFinalSplitCalculation(listOfViolatedQuatret, _splits[0], countTotalInConsistentQuatret);
                }
                else if (_splits[0]._CountTaxa > _splits[1]._CountTaxa)
                {
                    GetFinalSplitCalculation(listOfViolatedQuatret, _splits[1], countTotalInConsistentQuatret);
                }
                else
                {
                    GetFinalSplitCalculation(listOfViolatedQuatret, _splits[0], countTotalInConsistentQuatret);
                }

                //GetFinalSplitCalculation(listOfViolatedQuatret, _splits[0], countTotalInConsistentQuatret);
                //GetFinalSplitCalculation(listOfViolatedQuatret, _splits[1], countTotalInConsistentQuatret);
            }







        }

        public List<SplitModel> getFinalSplitList()
        {

            return this.FinalSplit;
        }

        public SplitModel getSuperSplitModel(List<SplitModel> ListSplitModel)
        {
            SplitModel SuperSplit = new SplitModel();
            var MinValue = ListSplitModel.Min(x => x._CountTaxa);
            var result = ListSplitModel.First(x => x._CountTaxa == MinValue);
            if (result != null)
                SuperSplit = result;
            return SuperSplit;
        }



        public List<SplitModel> getSplitArrays(Quartet q, SplitModel model)
        {
            List<SplitModel> list = new List<SplitModel>();

            Quartet Left = q;
            Quartet Right = Reverse(q);

            list.Add(getSplitModelAfterCalculation(Left, model));
            list.Add(getSplitModelAfterCalculation(Right, model));


            return list;
        }

        public SplitModel getSplitModelAfterCalculation(Quartet q, SplitModel model)
        {
            SplitModel objSplit = new SplitModel();
            objSplit._InputQuatret = q;
            objSplit._LeftPartOfSplit.Add(q._First_Taxa_Value);
            objSplit._LeftPartOfSplit.Add(q._Second_Taxa_Value);
            objSplit._LeftPartOfSplit = getUnionOfTaxaList(objSplit._LeftPartOfSplit, model._LeftPartOfSplit);

            objSplit._RightPartOfSplit.Add(q._Third_Taxa_Value);
            objSplit._RightPartOfSplit.Add(q._Fourth_Taxa_Value);
            objSplit._RightPartOfSplit = getUnionOfTaxaList(objSplit._RightPartOfSplit, model._RightPartOfSplit);

            return objSplit;
        }



        public List<string> getUnionOfTaxaList(List<string> root, List<string> current)
        {
            var distinct = root.Union(current).ToList();
            return distinct;
        }

        public List<string> removeCommonTaxaList(List<string> main, List<string> split)
        {
            var common = split.Intersect(main).ToList();
            split.RemoveAll(x => common.Contains(x));
            return split;
        }
        public Quartet Reverse(Quartet q)
        {

            Quartet Right = new Quartet();
            Right._First_Taxa_Value = q._Third_Taxa_Value;
            Right._Second_Taxa_Value = q._Fourth_Taxa_Value;
            Right._Third_Taxa_Value = q._First_Taxa_Value;
            Right._Fourth_Taxa_Value = q._Second_Taxa_Value;
            return Right;

        }


        #region Main Calculation

        public SplitModel CalculateIPartition(PartitionSet SetP, List<Quartet> ListInConsistantQuatrets)
        {

            SplitModel IPartSplit = new SplitModel();

            List<string> _LeftIPart = new List<string>();
            List<string> _RightIPart = new List<string>();

            List<string> _Left = new List<string>();
            List<string> _Right = new List<string>();

            _Left = SetP.PartitionList[0].TaxaList.Select(x => x._Taxa_Value).ToList();
            _Right = SetP.PartitionList[1].TaxaList.Select(x => x._Taxa_Value).ToList();

            List<string> ListPairsLeft = new List<string>();
            List<string> ListPairsRight = new List<string>();
            List<QuartetPair> pairs;
            foreach (Quartet q in ListInConsistantQuatrets)
            {
                pairs = new List<QuartetPair>();
                pairs = getQuartetPairs(q);

                if (isInSamePart(pairs[0], _Left))
                {

                    ListPairsLeft.Add(pairs[0]._First_Taxa_Value);
                    ListPairsLeft.Add(pairs[0]._Second_Taxa_Value);
                }
                else if (isInSamePart(pairs[0], _Right))
                {

                    ListPairsLeft.Add(pairs[0]._First_Taxa_Value);
                    ListPairsLeft.Add(pairs[0]._Second_Taxa_Value);
                }
                else
                {
                    ListPairsRight.Add(pairs[0]._First_Taxa_Value);
                    ListPairsRight.Add(pairs[0]._Second_Taxa_Value);
                }


                if (isInSamePart(pairs[1], _Left))
                {

                    ListPairsLeft.Add(pairs[1]._First_Taxa_Value);
                    ListPairsLeft.Add(pairs[1]._Second_Taxa_Value);
                }
                else if (isInSamePart(pairs[1], _Right))
                {

                    ListPairsLeft.Add(pairs[1]._First_Taxa_Value);
                    ListPairsLeft.Add(pairs[1]._Second_Taxa_Value);
                }
                else
                {
                    ListPairsRight.Add(pairs[1]._First_Taxa_Value);
                    ListPairsRight.Add(pairs[1]._Second_Taxa_Value);
                }

            }

            _LeftIPart = ListPairsLeft.Distinct().ToList();
            _RightIPart = ListPairsRight.Distinct().ToList();

            if (_LeftIPart.Count == 0)
            {
                _LeftIPart = _Left;
            }

            if (_RightIPart.Count == 0)
            {
                _RightIPart = _Right;
            }

            IPartSplit._InputQuatret = new Quartet();
            IPartSplit._LeftPartOfSplit = _LeftIPart;
            IPartSplit._RightPartOfSplit = _RightIPart;
            IPartSplit._LeftPartOfSplit.Sort();
            IPartSplit._RightPartOfSplit.Sort();
            IPartSplit._CountTaxa = _LeftIPart.Count() + _RightIPart.Count();

            return IPartSplit;
        }
        public SplitModel CalculateSuperSplit(List<Quartet> violted)
        {

            SplitCalculation Splitc;
            SplitModel SuperSplit = new SplitModel();
            if (violted.Count != 0)
            {
                Splitc = new SplitCalculation();
                if (violted.Count > 1)
                {
                    Splitc.GetFinalSplitCalculation(violted, new SplitModel(), violted.Count);
                    List<SplitModel> FinalSplit = new List<SplitModel>();
                    FinalSplit = Splitc.getFinalSplitList();
                    SuperSplit = Splitc.getSuperSplitModel(FinalSplit);
                }
                else if (violted.Count == 1)
                {
                    SuperSplit = new SplitModel();
                    SuperSplit._InputQuatret = violted[0];
                    SuperSplit._LeftPartOfSplit.Add(violted[0]._First_Taxa_Value);
                    SuperSplit._LeftPartOfSplit.Add(violted[0]._Second_Taxa_Value);
                    SuperSplit._RightPartOfSplit.Add(violted[0]._Third_Taxa_Value);
                    SuperSplit._RightPartOfSplit.Add(violted[0]._Fourth_Taxa_Value);
                    SuperSplit._LeftPartOfSplit.Sort();
                    SuperSplit._RightPartOfSplit.Sort();
                    SuperSplit._CountTaxa = SuperSplit._LeftPartOfSplit.Count() + SuperSplit._RightPartOfSplit.Count();
                }
            }
            return SuperSplit;
        }

        public SplitModel CalculateSecondarySplit(PartitionSet SetP, SplitModel SuperSplit)
        {

            SplitModel SecondarySplit = new SplitModel();
            List<string> _LeftSecondaryPart = new List<string>();
            List<string> _RightSecondaryPart = new List<string>();

            List<string> _Left1 = getUnionOfTaxaList(SuperSplit._LeftPartOfSplit, SetP.PartitionList[0].TaxaList.Select(x => x._Taxa_Value).ToList());
            List<string> _Left2 = getUnionOfTaxaList(SuperSplit._LeftPartOfSplit, SetP.PartitionList[1].TaxaList.Select(x => x._Taxa_Value).ToList());


            _LeftSecondaryPart = getMinSize(_Left1, _Left2);

            List<string> _Right1 = getUnionOfTaxaList(SuperSplit._RightPartOfSplit, SetP.PartitionList[0].TaxaList.Select(x => x._Taxa_Value).ToList());
            List<string> _Right2 = getUnionOfTaxaList(SuperSplit._RightPartOfSplit, SetP.PartitionList[1].TaxaList.Select(x => x._Taxa_Value).ToList());


            _RightSecondaryPart = getMinSize(_Right1, _Right2);

            SecondarySplit._InputQuatret = SuperSplit._InputQuatret;
            SecondarySplit._LeftPartOfSplit = _LeftSecondaryPart;
            SecondarySplit._RightPartOfSplit = _RightSecondaryPart;

            SecondarySplit._LeftPartOfSplit.Sort();
            SecondarySplit._RightPartOfSplit.Sort();

            SecondarySplit._CountTaxa = _LeftSecondaryPart.Count() + _RightSecondaryPart.Count();

            return SecondarySplit;
        }
        public List<string> getMinSize(List<string> List1, List<string> List2)
        {
            if (List1.Count() < List2.Count())
            {
                return List1;
            }
            else if (List1.Count() > List2.Count())
            {
                return List2;
            }
            else
                return List1;

        }


        public SplitModel CalculateHyBridSplit(PartitionSet SetP, SplitModel SecondarySplit, List<Quartet> ListInConsistantQuatrets)
        {

            SplitModel HybridSplit = new SplitModel();

            List<string> _LeftHyBridPart = new List<string>();
            List<string> _RightHyBridPart = new List<string>();

            List<string> _Left = getUnionOfTaxaList(SecondarySplit._LeftPartOfSplit, SetP.PartitionList[0].TaxaList.Select(x => x._Taxa_Value).ToList());
            List<string> _Right = getUnionOfTaxaList(SecondarySplit._RightPartOfSplit, SetP.PartitionList[1].TaxaList.Select(x => x._Taxa_Value).ToList());


            List<string> ListPairsLeft = new List<string>();
            List<string> ListPairsRight = new List<string>();
            List<QuartetPair> pairs;
            foreach (Quartet q in ListInConsistantQuatrets)
            {
                pairs = new List<QuartetPair>();
                pairs = getQuartetPairs(q);

                if (isInSamePart(pairs[0], _Left) && isInSamePart(pairs[1], _Left))
                {
                    ListPairsLeft.Add(pairs[0]._First_Taxa_Value);
                    ListPairsLeft.Add(pairs[0]._Second_Taxa_Value);

                    ListPairsRight.Add(pairs[1]._First_Taxa_Value);
                    ListPairsRight.Add(pairs[1]._Second_Taxa_Value);

                }
                else if (isInSamePart(pairs[0], _Left))
                {
                    ListPairsLeft.Add(pairs[0]._First_Taxa_Value);
                    ListPairsLeft.Add(pairs[0]._Second_Taxa_Value);

                    ListPairsRight.Add(pairs[1]._First_Taxa_Value);
                    ListPairsRight.Add(pairs[1]._Second_Taxa_Value);
                }
                else if (isInSamePart(pairs[1], _Left))
                {
                    ListPairsLeft.Add(pairs[1]._First_Taxa_Value);
                    ListPairsLeft.Add(pairs[1]._Second_Taxa_Value);

                    ListPairsRight.Add(pairs[0]._First_Taxa_Value);
                    ListPairsRight.Add(pairs[0]._Second_Taxa_Value);
                }


                if (isInSamePart(pairs[0], _Right) && isInSamePart(pairs[1], _Right))
                {
                    ListPairsRight.Add(pairs[0]._First_Taxa_Value);
                    ListPairsRight.Add(pairs[0]._Second_Taxa_Value);

                    ListPairsLeft.Add(pairs[1]._First_Taxa_Value);
                    ListPairsLeft.Add(pairs[1]._Second_Taxa_Value);
                }
                else if (isInSamePart(pairs[0], _Right))
                {
                    ListPairsRight.Add(pairs[0]._First_Taxa_Value);
                    ListPairsRight.Add(pairs[0]._Second_Taxa_Value);

                    ListPairsLeft.Add(pairs[1]._First_Taxa_Value);
                    ListPairsLeft.Add(pairs[1]._Second_Taxa_Value);
                }
                else if (isInSamePart(pairs[1], _Right))
                {
                    ListPairsRight.Add(pairs[1]._First_Taxa_Value);
                    ListPairsRight.Add(pairs[1]._Second_Taxa_Value);

                    ListPairsLeft.Add(pairs[0]._First_Taxa_Value);
                    ListPairsLeft.Add(pairs[0]._Second_Taxa_Value);
                }


            }

            _LeftHyBridPart = ListPairsLeft.Distinct().ToList();
            _RightHyBridPart = ListPairsRight.Distinct().ToList();


            HybridSplit._InputQuatret = SecondarySplit._InputQuatret;
            HybridSplit._LeftPartOfSplit = _LeftHyBridPart;
            HybridSplit._RightPartOfSplit = _RightHyBridPart;
            HybridSplit._LeftPartOfSplit.Sort();
            HybridSplit._RightPartOfSplit.Sort();
            HybridSplit._CountTaxa = _LeftHyBridPart.Count() + _RightHyBridPart.Count();

            return HybridSplit;
        }



        public bool isInSamePart(QuartetPair pair, List<string> Part)
        {
            bool isReturn = false;

            var v1 = Part.FindAll(x => x == pair._First_Taxa_Value).Count();
            var v2 = Part.FindAll(x => x == pair._Second_Taxa_Value).Count();
            if (v1 > 0 && v2 > 0)
            {
                isReturn = true;
            }

            return isReturn;

        }

        public List<QuartetPair> getQuartetPairs(Quartet q)
        {
            List<QuartetPair> pairs = new List<QuartetPair>();

            QuartetPair pair1 = new QuartetPair();
            pair1._First_Taxa_Value = q._First_Taxa_Value;
            pair1._Second_Taxa_Value = q._Second_Taxa_Value;
            pairs.Add(pair1);

            pair1 = new QuartetPair();
            pair1._First_Taxa_Value = q._Third_Taxa_Value;
            pair1._Second_Taxa_Value = q._Fourth_Taxa_Value;
            pairs.Add(pair1);

            return pairs;
        }


        public List<List<string>> getHyBridDepthOneTaxaList(PartitionSet SetP, SplitModel DuplicateSplit)
        {
            List<List<string>> list = new List<List<string>>();


            List<string> _Left = new List<string>();
            List<string> _Right = new List<string>();

            var vLeft = from t in SetP.PartitionList[0].TaxaList
                        select t._Taxa_Value;

            if (vLeft != null)
            {
                if (vLeft.Count() != 0)
                {
                    _Left = removeCommonTaxaList(vLeft.ToList(), DuplicateSplit._LeftPartOfSplit);
                }
            }

            var vRight = from t in SetP.PartitionList[1].TaxaList
                         select t._Taxa_Value;

            if (vRight != null)
            {
                if (vRight.Count() != 0)
                {
                    _Right = removeCommonTaxaList(vRight.ToList(), DuplicateSplit._RightPartOfSplit);
                }
            }

            list.Add(_Left);
            list.Add(_Right);

            return list;


        }

        public List<List<string>> getHyBridDepthOneTaxaListWithoutRemovingCommonTaxa(PartitionSet SetP, SplitModel DuplicateSplit)
        {
            List<List<string>> list = new List<List<string>>();
            List<string> _Left = new List<string>();
            List<string> _Right = new List<string>();

            
            _Left = DuplicateSplit._LeftPartOfSplit.Distinct().ToList();
            _Right = DuplicateSplit._RightPartOfSplit.Distinct().ToList();

            _Left.Sort();
            _Right.Sort();

            list.Add(_Left);
            list.Add(_Right);

            return list;


        }
        public List<List<string>> getHyBridIPartitionDepthOneTaxaList(PartitionSet SetP, SplitModel DuplicateSplit)
        {
            List<List<string>> list = new List<List<string>>();


            List<string> _Left = new List<string>();
            List<string> _Right = new List<string>();

            var vLeft = from t in SetP.PartitionList[0].TaxaList
                        select t._Taxa_Value;

            if (vLeft != null)
            {
                if (vLeft.Count() != 0)
                {

                    _Left = removeCommonTaxaList(DuplicateSplit._LeftPartOfSplit, vLeft.ToList());
                }
            }

            var vRight = from t in SetP.PartitionList[1].TaxaList
                         select t._Taxa_Value;

            if (vRight != null)
            {
                if (vRight.Count() != 0)
                {
                    _Right = DuplicateSplit._RightPartOfSplit;
                }
            }

            list.Add(_Left);
            list.Add(_Right);

            return list;


        }
        #endregion





    }
}
