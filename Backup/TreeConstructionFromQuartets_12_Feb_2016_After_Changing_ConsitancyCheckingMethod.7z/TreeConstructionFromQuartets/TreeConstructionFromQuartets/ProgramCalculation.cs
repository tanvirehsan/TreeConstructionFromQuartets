﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TreeConstructionFromQuartets.Model;

namespace TreeConstructionFromQuartets
{
    public class ProgramCalculation
    {
        public List<string> getUnionOfTaxaList(List<string> root, List<string> current)
        {
            var distinct = root.Union(current).ToList();
            return distinct;
        }

        public void StepByStep()
        {
            #region Step:1 Find Depth One Chain and Consistancy Calculation
            ConsistancyCalculation obj = new ConsistancyCalculation();
            obj.CalculateConsistancy();

            // Getting the GainTable After Initial Bipartition
            GainTable GB = obj.getFinalGainTableAfterGainCalculation();
            // Getting Partition with maximum Gained Taxa 
            PartitionSet SetP = GB.PartitionSet;

            // Getting Differred, Isolated And Violated Quatret Before Devide and Conquer
            List<Quartet> _DifferedQuatretListAfterGain = obj.getDifferedQuatretListAfterGain();
            List<Quartet> _IsolatedQuatretListAfterGain = obj.getIsolatedQuatretListAfterGain();
            List<Quartet> _ViolatedQuatretListAfterGain = obj.getViolatedQuatretListAfterGain();

            // Getting Depth One Chain After Devide And Conquer
            List<ConsistencyDataModel> _ListConsistencyDataModel = obj.getListConsistencyDataModel();

            // Getting Consistent and Inconsistent Quatret 
            List<Quartet> _DifferredConsistentAfterDevideAndConquer = obj.getDifferedQuatretConsistentAfterDevideAndConquer();
            List<Quartet> _IsolatedConsistentAfterDevideAndConquer = obj.getIsolatedQuatretConsistentAfterDevideAndConquer();
            List<Quartet> _ViolatedConsistentAfterDevideAndConquer = obj.getViolatedQuatretConsistentAfterDevideAndConquer();

            List<Quartet> _IsolatedInConsistentAfterDevideAndConquer = obj.getIsolatedQuatretInConsistentAfterDevideAndConquer();
            List<Quartet> _DifferredInConsistentAfterDevideAndConquer = obj.getDifferedQuatretInConsistentAfterDevideAndConquer();
            List<Quartet> _ViolatedInConsistentAfterDevideAndConquer = obj.getViolatedQuatretInConsistentAfterDevideAndConquer();

            #endregion

            #region Step:2 Get The Input (Isolated ,Violated, Differred )

            var vAllInConsistentQuatret = _IsolatedInConsistentAfterDevideAndConquer.Concat(_DifferredInConsistentAfterDevideAndConquer).Concat(_ViolatedInConsistentAfterDevideAndConquer);
            OutputProcessing.WriteListOfQuatretInConsistancy(vAllInConsistentQuatret.ToList());



            #endregion

            #region Step:2 Calculate Super Split List using All Inconsistent Quatret

            SplitCalculation objSplitCalculation = new SplitCalculation();
            SplitModel SuperSplit = new SplitModel();
            if (vAllInConsistentQuatret.ToList().Count != 0)
            {
                SuperSplit = objSplitCalculation.CalculateSuperSplit(vAllInConsistentQuatret.ToList());
                OutputProcessing.WriteSplitValues(SuperSplit, "Super Split");
            }

            #endregion





            #region Step:4 Calculate HyBrid DepthOne List

            List<List<string>> HyBridDepthOneList = new List<List<string>>();
            if (SuperSplit._LeftPartOfSplit.Count < SuperSplit._RightPartOfSplit.Count)
            {
                SuperSplit._RightPartOfSplit = new List<string>();
            }
            else if (SuperSplit._RightPartOfSplit.Count < SuperSplit._LeftPartOfSplit.Count)
            {
                SuperSplit._LeftPartOfSplit = new List<string>();
            }
            else if (SuperSplit._RightPartOfSplit.Count == SuperSplit._LeftPartOfSplit.Count)
            {
                SuperSplit._LeftPartOfSplit = new List<string>();
            }
            HyBridDepthOneList = objSplitCalculation.getHyBridDepthOneTaxaListWithoutRemovingCommonTaxa(SetP, SuperSplit);

            List<string> LeftMost = HyBridDepthOneList[0];
            List<string> RightMost = HyBridDepthOneList[1];

            List<DepthOneTreeNode> DepthOneTreeNodeLeft = new List<DepthOneTreeNode>();
            List<DepthOneTreeNode> DepthOneTreeNodeRight = new List<DepthOneTreeNode>();
            DepthOneTreeNode __node;
            int pos = 0;

            foreach (string tx in LeftMost)
            {
                __node = new DepthOneTreeNode();
                __node._Position = pos;
                __node._Taxa_Value = tx;
                pos++;
                DepthOneTreeNodeLeft.Add(__node);

            }


            pos = 0;
            foreach (string tx in RightMost)
            {
                __node = new DepthOneTreeNode();
                __node._Position = pos;
                __node._Taxa_Value = tx;
                pos++;
                DepthOneTreeNodeRight.Add(__node);

            }

            _ListConsistencyDataModel.Insert(0, new ConsistencyDataModel()
            {
                _Isolated_Quatret = _ListConsistencyDataModel[0]._Isolated_Quatret,
                _Differed_Quatret = _ListConsistencyDataModel[0]._Differed_Quatret,
                _Violated_Quatret = _ListConsistencyDataModel[0]._Violated_Quatret,
                _DepthOneChain = new List<DepthOneTreeNode>(DepthOneTreeNodeLeft)
            });

            _ListConsistencyDataModel.Add(new ConsistencyDataModel()
            {
                _Isolated_Quatret = _ListConsistencyDataModel[0]._Isolated_Quatret,
                _Differed_Quatret = _ListConsistencyDataModel[0]._Differed_Quatret,
                _Violated_Quatret = _ListConsistencyDataModel[0]._Violated_Quatret,
                _DepthOneChain = new List<DepthOneTreeNode>(DepthOneTreeNodeRight)
            });

            OutputProcessing.PrintHyBridDepthOneTree(_ListConsistencyDataModel);
            OutputProcessing.GenerateInputForHyBridDepthOneTree(_ListConsistencyDataModel);
            OutputProcessing.GenerateCountOfDuplicateTaxa(DepthOneTreeNodeLeft, DepthOneTreeNodeRight);
            #endregion
        }

        public void QuatretComparisonTechnique()
        {
            #region Step:1 Find Depth One Chain and Consistancy Calculation
            ConsistancyCalculation obj = new ConsistancyCalculation();
            obj.CalculateConsistancy();

            // Getting the GainTable After Initial Bipartition
            GainTable GB = obj.getFinalGainTableAfterGainCalculation();
            // Getting Partition with maximum Gained Taxa 
            PartitionSet SetP = GB.PartitionSet;

            // Getting Differred, Isolated And Violated Quatret Before Devide and Conquer
            List<Quartet> _DifferedQuatretListAfterGain = obj.getDifferedQuatretListAfterGain();
            List<Quartet> _IsolatedQuatretListAfterGain = obj.getIsolatedQuatretListAfterGain();
            List<Quartet> _ViolatedQuatretListAfterGain = obj.getViolatedQuatretListAfterGain();

            // Getting Depth One Chain After Devide And Conquer
            List<ConsistencyDataModel> _ListConsistencyDataModel = obj.getListConsistencyDataModel();

            // Getting Consistent and Inconsistent Quatret 
            List<Quartet> _DifferredConsistentAfterDevideAndConquer = obj.getDifferedQuatretConsistentAfterDevideAndConquer();
            List<Quartet> _IsolatedConsistentAfterDevideAndConquer = obj.getIsolatedQuatretConsistentAfterDevideAndConquer();
            List<Quartet> _ViolatedConsistentAfterDevideAndConquer = obj.getViolatedQuatretConsistentAfterDevideAndConquer();

            List<Quartet> _IsolatedInConsistentAfterDevideAndConquer = obj.getIsolatedQuatretInConsistentAfterDevideAndConquer();
            List<Quartet> _DifferredInConsistentAfterDevideAndConquer = obj.getDifferedQuatretInConsistentAfterDevideAndConquer();
            List<Quartet> _ViolatedInConsistentAfterDevideAndConquer = obj.getViolatedQuatretInConsistentAfterDevideAndConquer();

            #endregion

            #region Step:2 Get The Input (Isolated ,Violated, Differred )

            var vAllInConsistentQuatret = _IsolatedInConsistentAfterDevideAndConquer.Concat(_DifferredInConsistentAfterDevideAndConquer).Concat(_ViolatedInConsistentAfterDevideAndConquer);
            OutputProcessing.WriteListOfQuatretInConsistancy(vAllInConsistentQuatret.ToList());

            SplitCalculation objIPartition = new SplitCalculation();
            SplitModel split = new SplitModel();
            if (_ViolatedQuatretListAfterGain.Count != 0)
            {
                split = objIPartition.CalculateIPartition(SetP, vAllInConsistentQuatret.ToList());
                OutputProcessing.WriteSplitValues(split, "IPartition Split");
            }

            #endregion

            #region Step:4 Calculate HyBrid DepthOne List

            List<List<string>> HyBridDepthOneList = new List<List<string>>();
            HyBridDepthOneList = objIPartition.getHyBridIPartitionDepthOneTaxaList(SetP, split);

            List<string> LeftMost = HyBridDepthOneList[0];
            List<string> RightMost = HyBridDepthOneList[1];

            List<DepthOneTreeNode> DepthOneTreeNodeLeft = new List<DepthOneTreeNode>();
            List<DepthOneTreeNode> DepthOneTreeNodeRight = new List<DepthOneTreeNode>();
            DepthOneTreeNode __node;
            int pos = 0;

            foreach (string tx in LeftMost)
            {
                __node = new DepthOneTreeNode();
                __node._Position = pos;
                __node._Taxa_Value = tx;
                pos++;
                DepthOneTreeNodeLeft.Add(__node);

            }


            pos = 0;
            foreach (string tx in RightMost)
            {
                __node = new DepthOneTreeNode();
                __node._Position = pos;
                __node._Taxa_Value = tx;
                pos++;
                DepthOneTreeNodeRight.Add(__node);

            }

            _ListConsistencyDataModel.Insert(0, new ConsistencyDataModel()
            {
                _Isolated_Quatret = _ListConsistencyDataModel[0]._Isolated_Quatret,
                _Differed_Quatret = _ListConsistencyDataModel[0]._Differed_Quatret,
                _Violated_Quatret = _ListConsistencyDataModel[0]._Violated_Quatret,
                _DepthOneChain = new List<DepthOneTreeNode>(DepthOneTreeNodeLeft)
            });

            _ListConsistencyDataModel.Add(new ConsistencyDataModel()
            {
                _Isolated_Quatret = _ListConsistencyDataModel[0]._Isolated_Quatret,
                _Differed_Quatret = _ListConsistencyDataModel[0]._Differed_Quatret,
                _Violated_Quatret = _ListConsistencyDataModel[0]._Violated_Quatret,
                _DepthOneChain = new List<DepthOneTreeNode>(DepthOneTreeNodeRight)
            });

            OutputProcessing.PrintHyBridDepthOneTree(_ListConsistencyDataModel);
            OutputProcessing.GenerateInputForHyBridDepthOneTree(_ListConsistencyDataModel);
            OutputProcessing.GenerateCountOfDuplicateTaxa(DepthOneTreeNodeLeft, DepthOneTreeNodeRight);
            #endregion

        }

        public void StepByStepWithAllInconsistentQuatret()
        {
            #region Step:1 Find Depth One Chain and Consistancy Calculation
            ConsistancyCalculation obj = new ConsistancyCalculation();
            obj.CalculateConsistancy();

            // Getting the GainTable After Initial Bipartition
            GainTable GB = obj.getFinalGainTableAfterGainCalculation();
            // Getting Partition with maximum Gained Taxa 
            PartitionSet SetP = GB.PartitionSet;

            // Getting Differred, Isolated And Violated Quatret Before Devide and Conquer
            List<Quartet> _DifferedQuatretListAfterGain = obj.getDifferedQuatretListAfterGain();
            List<Quartet> _IsolatedQuatretListAfterGain = obj.getIsolatedQuatretListAfterGain();
            List<Quartet> _ViolatedQuatretListAfterGain = obj.getViolatedQuatretListAfterGain();

            // Getting Depth One Chain After Devide And Conquer
            List<ConsistencyDataModel> _ListConsistencyDataModel = obj.getListConsistencyDataModel();


            // Getting Consistent and Inconsistent Quatret 
            List<Quartet> _DifferredConsistentAfterDevideAndConquer = obj.getDifferedQuatretConsistentAfterDevideAndConquer();
            List<Quartet> _IsolatedConsistentAfterDevideAndConquer = obj.getIsolatedQuatretConsistentAfterDevideAndConquer();
            List<Quartet> _ViolatedConsistentAfterDevideAndConquer = obj.getViolatedQuatretConsistentAfterDevideAndConquer();

            List<Quartet> _IsolatedInConsistentAfterDevideAndConquer = obj.getIsolatedQuatretInConsistentAfterDevideAndConquer();
            List<Quartet> _DifferredInConsistentAfterDevideAndConquer = obj.getDifferedQuatretInConsistentAfterDevideAndConquer();
            List<Quartet> _ViolatedInConsistentAfterDevideAndConquer = obj.getViolatedQuatretInConsistentAfterDevideAndConquer();


            #endregion

            #region Step:2 Get The Input (Isolated ,Violated, Differred )

            var vAllInConsistentQuatret = _IsolatedInConsistentAfterDevideAndConquer.Concat(_DifferredInConsistentAfterDevideAndConquer).Concat(_ViolatedInConsistentAfterDevideAndConquer);
            OutputProcessing.WriteListOfQuatretInConsistancy(vAllInConsistentQuatret.ToList());
            #endregion

            #region Step:3 Calculate Super Split List using All Inconsistent Quatret

            SplitCalculation objSplitCalculation = new SplitCalculation();
            SplitModel SuperSplit = new SplitModel();
            if (vAllInConsistentQuatret.ToList().Count != 0)
            {
                SuperSplit = objSplitCalculation.CalculateSuperSplit(vAllInConsistentQuatret.ToList());
                OutputProcessing.WriteSplitValues(SuperSplit, "Super Split");
            }

            #endregion

            #region Step:4 Calculate HyBrid DepthOne List

            List<List<string>> HyBridDepthOneList = new List<List<string>>();
            HyBridDepthOneList = objSplitCalculation.getHyBridDepthOneTaxaListWithoutRemovingCommonTaxa(SetP, SuperSplit);

            List<string> LeftMost = HyBridDepthOneList[0];
            List<string> RightMost = HyBridDepthOneList[1];

            List<DepthOneTreeNode> DepthOneTreeNodeLeft = new List<DepthOneTreeNode>();
            List<DepthOneTreeNode> DepthOneTreeNodeRight = new List<DepthOneTreeNode>();
            DepthOneTreeNode __node;
            int pos = 0;

            foreach (string tx in LeftMost)
            {
                __node = new DepthOneTreeNode();
                __node._Position = pos;
                __node._Taxa_Value = tx;
                pos++;
                DepthOneTreeNodeLeft.Add(__node);

            }


            pos = 0;
            foreach (string tx in RightMost)
            {
                __node = new DepthOneTreeNode();
                __node._Position = pos;
                __node._Taxa_Value = tx;
                pos++;
                DepthOneTreeNodeRight.Add(__node);

            }

            _ListConsistencyDataModel.Insert(0, new ConsistencyDataModel()
            {
                _Isolated_Quatret = _ListConsistencyDataModel[0]._Isolated_Quatret,
                _Differed_Quatret = _ListConsistencyDataModel[0]._Differed_Quatret,
                _Violated_Quatret = _ListConsistencyDataModel[0]._Violated_Quatret,
                _DepthOneChain = new List<DepthOneTreeNode>(DepthOneTreeNodeLeft)
            });

            _ListConsistencyDataModel.Add(new ConsistencyDataModel()
            {
                _Isolated_Quatret = _ListConsistencyDataModel[0]._Isolated_Quatret,
                _Differed_Quatret = _ListConsistencyDataModel[0]._Differed_Quatret,
                _Violated_Quatret = _ListConsistencyDataModel[0]._Violated_Quatret,
                _DepthOneChain = new List<DepthOneTreeNode>(DepthOneTreeNodeRight)
            });

            OutputProcessing.PrintHyBridDepthOneTree(_ListConsistencyDataModel);
            OutputProcessing.GenerateInputForHyBridDepthOneTree(_ListConsistencyDataModel);
            OutputProcessing.GenerateCountOfDuplicateTaxa(DepthOneTreeNodeLeft, DepthOneTreeNodeRight);
            #endregion
        }
    }
}
